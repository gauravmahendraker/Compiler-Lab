Q1) For question 1 provide the input from terminal , and the program(q1.cpp) will return if its a valid identifier or not
Q2) For question 2, the input file is q2.txt, the program(q2.cpp) will identify tokens from q2.txt file
Q3) For question 3, the input file is q3.txt, the program(q3.cpp) will return the count of char, linespaces and linebreaks from q3.txt file.