The programmes are written in C++ language. 
We can first compile the cpp files and then run the executable using G++ compiler.

If file is filename.cpp then
Compile using
g++ filename.cpp -o filename
Run using 
./filename

Then the output of the programme will be printed in the terminal.

For q1) Consonant count and vowel count are printed in terminal
For q2) If the given String is keyword the programme prints "IS keyword" else prints "Not a Keyword"
For q3) If given line is a comment it prints "String is a comment" else prints "String is not a comment"

